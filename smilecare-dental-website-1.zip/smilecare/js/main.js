/* ===== SMILECARE DENTAL CLINIC - MAIN JS ===== */

document.addEventListener('DOMContentLoaded', () => {

  // ===== LOADER =====
  const loader = document.getElementById('loader');
  window.addEventListener('load', () => {
    setTimeout(() => { loader.classList.add('hidden'); }, 800);
  });

  // ===== STICKY HEADER =====
  const header = document.getElementById('header');
  const onScroll = () => {
    header.classList.toggle('scrolled', window.scrollY > 50);
    const backTop = document.getElementById('backToTop');
    if (backTop) backTop.classList.toggle('visible', window.scrollY > 400);
  };
  window.addEventListener('scroll', onScroll, { passive: true });

  // ===== MOBILE NAV =====
  const hamburger = document.querySelector('.hamburger');
  const mobileNav = document.querySelector('.mobile-nav');
  hamburger?.addEventListener('click', () => {
    hamburger.classList.toggle('open');
    mobileNav.classList.toggle('open');
    document.body.style.overflow = mobileNav.classList.contains('open') ? 'hidden' : '';
  });
  document.querySelectorAll('.mobile-nav a').forEach(a => {
    a.addEventListener('click', () => {
      hamburger.classList.remove('open');
      mobileNav.classList.remove('open');
      document.body.style.overflow = '';
    });
  });

  // ===== SCROLL REVEAL =====
  const revealEls = document.querySelectorAll('.reveal, .reveal-left, .reveal-right');
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry, i) => {
      if (entry.isIntersecting) {
        const delay = entry.target.dataset.delay || 0;
        setTimeout(() => entry.target.classList.add('visible'), delay * 100);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });
  revealEls.forEach(el => observer.observe(el));

  // ===== ANIMATED COUNTER =====
  const counters = document.querySelectorAll('[data-count]');
  const countObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const el = entry.target;
        const target = parseInt(el.dataset.count);
        let current = 0;
        const step = target / 60;
        const timer = setInterval(() => {
          current = Math.min(current + step, target);
          el.textContent = Math.floor(current).toLocaleString();
          if (current >= target) clearInterval(timer);
        }, 25);
        countObserver.unobserve(el);
      }
    });
  }, { threshold: 0.3 });
  counters.forEach(c => countObserver.observe(c));

  // ===== TESTIMONIAL CAROUSEL =====
  const track = document.querySelector('.testi-track');
  const dots = document.querySelectorAll('.testi-dot');
  const cards = document.querySelectorAll('.testi-card');
  let currentSlide = 0;
  let autoSlide;
  const visibleCards = () => window.innerWidth < 900 ? 1 : 3;

  function goToSlide(n) {
    const max = cards.length - visibleCards();
    currentSlide = Math.max(0, Math.min(n, max));
    const cardWidth = cards[0]?.offsetWidth + 14;
    track.style.transform = `translateX(-${currentSlide * cardWidth}px)`;
    dots.forEach((d, i) => d.classList.toggle('active', i === currentSlide));
  }
  document.querySelector('.testi-prev')?.addEventListener('click', () => {
    goToSlide(currentSlide - 1); resetAuto();
  });
  document.querySelector('.testi-next')?.addEventListener('click', () => {
    goToSlide(currentSlide + 1); resetAuto();
  });
  dots.forEach((d, i) => d.addEventListener('click', () => { goToSlide(i); resetAuto(); }));

  function startAuto() { autoSlide = setInterval(() => {
    goToSlide(currentSlide + 1 > cards.length - visibleCards() ? 0 : currentSlide + 1);
  }, 4000); }
  function resetAuto() { clearInterval(autoSlide); startAuto(); }
  startAuto();

  // ===== FAQ ACCORDION =====
  document.querySelectorAll('.faq-item').forEach(item => {
    item.querySelector('.faq-q')?.addEventListener('click', () => {
      const isOpen = item.classList.contains('open');
      document.querySelectorAll('.faq-item.open').forEach(i => {
        i.classList.remove('open');
        i.querySelector('.faq-a').style.maxHeight = '0';
      });
      if (!isOpen) {
        item.classList.add('open');
        const a = item.querySelector('.faq-a');
        a.style.maxHeight = a.scrollHeight + 'px';
      }
    });
  });

  // ===== GALLERY TABS =====
  document.querySelectorAll('.gallery-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.gallery-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
    });
  });

  // ===== BACK TO TOP =====
  document.getElementById('backToTop')?.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  // ===== ACTIVE NAV LINK =====
  const sections = document.querySelectorAll('section[id]');
  const navLinks = document.querySelectorAll('.nav-links a');
  const navObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        navLinks.forEach(a => {
          a.classList.toggle('active', a.getAttribute('href') === '#' + entry.target.id);
        });
      }
    });
  }, { threshold: 0.4 });
  sections.forEach(s => navObserver.observe(s));

  // ===== FORM HANDLERS =====
  document.querySelectorAll('form').forEach(form => {
    form.addEventListener('submit', e => {
      e.preventDefault();
      const btn = form.querySelector('button[type="submit"], .form-submit');
      if (btn) {
        const orig = btn.textContent;
        btn.textContent = '✓ Submitted Successfully!';
        btn.style.background = 'linear-gradient(135deg, #22c55e, #16a34a)';
        setTimeout(() => {
          btn.textContent = orig;
          btn.style.background = '';
          form.reset();
        }, 3000);
      }
    });
  });

  // ===== STAGGER REVEAL CHILDREN =====
  document.querySelectorAll('[data-stagger]').forEach(parent => {
    const children = parent.children;
    Array.from(children).forEach((child, i) => {
      child.style.transitionDelay = `${i * 80}ms`;
    });
  });

  // Open first FAQ on load
  const firstFaq = document.querySelector('.faq-item');
  if (firstFaq) {
    firstFaq.classList.add('open');
    firstFaq.querySelector('.faq-a').style.maxHeight = '200px';
  }

});
